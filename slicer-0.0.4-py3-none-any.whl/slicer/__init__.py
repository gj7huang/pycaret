""" Unified slicing for data.
Less API, less think.
"""
from .slicer import Slicer, Alias, Obj
